package com.autoidentification.controllers;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.naming.java.javaURLContextFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.servlet.ModelAndView;

import com.autoidentification.dao.*;
import com.autoidentification.models.*;
import com.autoidentification.services.*;

@Controller
@RequestMapping(value = "/emp")
public class EmployeeController {
	@Autowired
	private EmployeeServices employeeservices;

	@GetMapping("/")
	public String empLogin(Model model) {
		BankEmployeeLogin bankemployeelogin = new BankEmployeeLogin();
		model.addAttribute("bankemployeelogin", bankemployeelogin);
		return "login";
	}

	@PostMapping("/verifylogin")
	public String empLoginVerify(@ModelAttribute("bankemployeelogin") BankEmployeeLogin bel, Model model,
			HttpSession session) {
		session.setAttribute("userid", bel.getUserId());
		int res = employeeservices.getBankEmployee(bel);
		if (res == 1) {

			return "employeehome";
		} else if (res == 2) {
			model.addAttribute("message", "please wait for admin approval");
			return "login";
		} else if (res == 3) {
			model.addAttribute("message", "please check the details");
			return "login";
		}
		model.addAttribute("message", "you are not registered please regsiter");
		return "login";
	}

	@GetMapping("/register")
	public String empRegister(Model empmodel, Model secmodel) {
		BankEmployee bankemployee = new BankEmployee();
		empmodel.addAttribute("bankemployee", bankemployee);

		Security secure = new Security();
		secmodel.addAttribute("secure", secure);
		return "registration";
	}

	@PostMapping("/verifyregister")
	public String verifyEmpRegister(@ModelAttribute("bankemployee") BankEmployee be,
			@ModelAttribute("secure") Security sec, Model model) {
		sec.setUserId(be.getUserId());
		;
		be.setSecurity(sec);
		be.setStatus("deactivate");
		int res = employeeservices.storeEmployee(be);
		BankEmployeeLogin bankemployeelogin = new BankEmployeeLogin();
		model.addAttribute("bankemployeelogin", bankemployeelogin);
		if (res == 1) {
			model.addAttribute("message", "you are succesfully registered");
			return "login";
		} else if (res == 2) {
			model.addAttribute("message", "you are already registered");
			return "login";
		} else {
			model.addAttribute("message", "something went wrong");
			return "login";
		}
	}

	@GetMapping("/homeemp")
	public String empHome(Model model) {

		return "employeehome";
	}

	@GetMapping("/forgetUserId")
	public String forgetId(Model model) {
		return "ForgotUserid";

	}

	@GetMapping("/forgetpassword")
	public String forgetPwd(Model model) {

		return "Forgotpassword";
	}

}
