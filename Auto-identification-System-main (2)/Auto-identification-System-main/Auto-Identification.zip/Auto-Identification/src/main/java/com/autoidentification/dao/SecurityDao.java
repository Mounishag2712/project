package com.autoidentification.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.autoidentification.models.*;

public interface SecurityDao extends JpaRepository<Security, String> {

	public Security findByUserId(String userId);

}
