package com.autoidentification.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestMapping;

import com.autoidentification.models.*;

import com.autoidentification.services.*;

@Controller
@RequestMapping("/admin")
public class AdminController {
	@Autowired
	private AdminServices adminservices;

	// @Autowired
	// private AdminDao admindao;

	@GetMapping("/")
	public String aLogin(Model model) {
		AdminLogin adminlogin = new AdminLogin();
		model.addAttribute("adminlogin", adminlogin);
		return "AdminLogin";
	}

	@PostMapping("/logadmin")
	public String adminVerifyLogin(@ModelAttribute("adminlogin") AdminLogin al, Model model, HttpSession session)

	{
		session.setAttribute("userid", al.getUserId());
		int res = adminservices.getAdmin(al);
		if (res == 1) {
			return "sampleadminhome";
		} else if (res == 2) {
			model.addAttribute("message", "your are not yet registered");
			return "AdminLogin";
		}
		model.addAttribute("message", "please check your details");

		return "AdminLogin";
	}

	@GetMapping("/regadmin")
	public String aRegister(Model adminmodel, Model secmodel) {
		Admin admin = new Admin();
		adminmodel.addAttribute("admin", admin);
		Security secure = new Security();
		secmodel.addAttribute("securityque", secure);
		return "AdminRegistration";
	}

	@PostMapping("/adminregvalidate")
	public String adminVerifyRegistration(@ModelAttribute("admin") Admin ad,
			@ModelAttribute("securityque") Security sec, Model model) {
		sec.setUserId(ad.getUserId());
		ad.setSecurity(sec);
		System.out.println(ad);
		int res = adminservices.storeAdmin(ad);
		AdminLogin adminlogin = new AdminLogin();
		model.addAttribute("adminlogin", adminlogin);
		if (res == 1) {
			model.addAttribute("message", "succesfully registered");

			return "AdminLogin";
		} else if (res == 2) {
			model.addAttribute("message", "already registered");

			return "AdminLogin";
		} else {
			model.addAttribute("message", "something went wrong");

			return "AdminLogin";
		}
	}

	@GetMapping("/homeadmin")
	public String adminHome(Model model) {

		return "sampleadminhome";
	}

	@GetMapping("/forgetUId")
	public String forgetId(Model model) {
		return "AdminForgotUserId";
	}

	@GetMapping("/forgetpwd")
	public String forgetPwd(Model model) {

		return "AdminForgotpassword";
	}

	@GetMapping("/logout")
	public String logOut() {
		return "home";
	}
}
