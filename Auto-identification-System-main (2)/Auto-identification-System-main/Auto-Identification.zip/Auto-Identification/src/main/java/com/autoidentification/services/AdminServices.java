package com.autoidentification.services;

import java.util.List;
import com.autoidentification.models.*;

public interface AdminServices {
	public int storeAdmin(Admin admin);

	public int getAdmin(AdminLogin adminlogin);

	public List<BankEmployee> emplist();

	//public Security getSecurity(String contactNumber);

	//public Security getSecuritypwd(String userId);

	public boolean updatePassword(Admin admin);

	public Admin getuserdata(String userId);
}