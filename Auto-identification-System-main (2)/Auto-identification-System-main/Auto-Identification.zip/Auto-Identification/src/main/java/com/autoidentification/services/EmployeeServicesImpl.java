package com.autoidentification.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.autoidentification.models.*;
import com.autoidentification.models.BankEmployee;
import com.autoidentification.dao.*;

@Service
@Component
public class EmployeeServicesImpl implements EmployeeServices {
	@Autowired
	private EmployeeDao employeedao;

	

	@Override
	public int storeEmployee(BankEmployee bankemployee) {
		BankEmployee be = employeedao.findByUserId(bankemployee.getUserId());
		if (be == null) {
			BankEmployee emp = employeedao.save(bankemployee);
			if (emp != null) {
				return 1;
			} else {
				return 0;
			}
		}
		return 2;
	}

	@Override
	public List<BankEmployee> employeeList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getBankEmployee(BankEmployeeLogin bankemployeelogin) {
		BankEmployee be = employeedao.findByUserId(bankemployeelogin.getUserId());
		if (be != null) {
			if (be.getPassword().equals(bankemployeelogin.getPassword())) {
				if (be.getStatus().equals("activate")) {
					return 1;
				} else {
					return 2;
				}
			} else {
				return 3;
			}
		}
		return 0;
	}

	@Override
	public boolean updatePassword(BankEmployee bankEmployee) {

		BankEmployee be = employeedao.save(bankEmployee);

		if (be != null) {

			return true;
		} else {
			return false;
		}

	}

	@Override
	public BankEmployee getuserdata(String userId) {

		return employeedao.getEmployee(userId);
	}

}

