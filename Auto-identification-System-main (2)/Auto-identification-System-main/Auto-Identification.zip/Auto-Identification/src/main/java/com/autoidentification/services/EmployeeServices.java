package com.autoidentification.services;

import java.util.List;

import com.autoidentification.models.*;
import com.autoidentification.models.BankEmployee;

public interface EmployeeServices {
	public int storeEmployee(BankEmployee bankemployee);

	public int getBankEmployee(BankEmployeeLogin bankemployeelogin);

	public List<BankEmployee> employeeList();

	public boolean updatePassword(BankEmployee bankEmployee);

	public BankEmployee getuserdata(String userId);

}
